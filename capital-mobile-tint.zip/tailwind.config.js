module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: "#007BFF",
        dark: "#1C1C1C",
      },
    },
  },
  plugins: [],
};
