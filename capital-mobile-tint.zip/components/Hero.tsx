export default function Hero({ title, subtitle, ctaPrimary, ctaSecondary }) {
  return (
    <section className="relative bg-[url('/images/hero-car.jpg')] bg-cover bg-center text-white h-[80vh] flex flex-col justify-center items-center text-center">
      <div className="bg-black/60 absolute inset-0"></div>
      <div className="relative z-10 max-w-2xl px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">{title}</h1>
        <p className="text-lg mb-8">{subtitle}</p>
        <div className="space-x-4">
          <a href="/contact" className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded text-white font-semibold">{ctaPrimary}</a>
          <a href="/contact" className="border border-white px-6 py-3 rounded hover:bg-white hover:text-black transition">{ctaSecondary}</a>
        </div>
      </div>
    </section>
  );
}
