export default function ServiceCard({ image, title, description, link }) {
  return (
    <a href={link} className="block bg-white rounded shadow hover:shadow-lg transition overflow-hidden">
      <img src={image} alt={title} className="w-full h-48 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <span className="text-blue-600 font-semibold">Learn More →</span>
      </div>
    </a>
  );
}
