# Capital Mobile Window Tint & Removal

Next.js 14 + Tailwind CSS website built for Capital Mobile Window Tint & Removal.

**Deploy:**
1. `npm install`
2. `npm run dev`
3. Deploy to [Vercel](https://vercel.com) 🚀