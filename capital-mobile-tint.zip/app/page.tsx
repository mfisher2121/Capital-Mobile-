import Hero from "@/components/Hero";
import ServiceCard from "@/components/ServiceCard";
import CTA from "@/components/CTA";

export default function Home() {
  return (
    <main className="bg-gray-50 text-gray-900">
      <Hero
        title="Mobile Window Tinting in DC, Maryland & Virginia"
        subtitle="We Come to You — Premium Ceramic & Carbon Tinting for Cars, Homes & Businesses"
        ctaPrimary="Get a Free Quote"
        ctaSecondary="Book Same-Day Service"
      />
      <section className="py-16 max-w-7xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-8">Our Tinting Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <ServiceCard
            image="/images/hero-car.jpg"
            title="Automotive Tinting"
            description="Enhance your ride’s comfort, privacy, and style with our mobile tinting service."
            link="/automotive"
          />
          <ServiceCard
            image="/images/home-tint.jpg"
            title="Residential Tinting"
            description="Stay cool, save on energy, and protect your home’s interiors from UV damage."
            link="/residential"
          />
          <ServiceCard
            image="/images/office-tint.jpg"
            title="Commercial Tinting"
            description="Lower your business energy costs and improve employee comfort."
            link="/commercial"
          />
        </div>
      </section>
      <CTA
        title="Ready for Cooler, Safer Windows?"
        subtitle="Book your mobile tint appointment today — serving DC, Maryland, and Virginia."
        buttonText="Request a Quote"
      />
    </main>
  );
}
